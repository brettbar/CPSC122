void getNumber(int *n)
{
	cout << "Enter a number: ";
	cin >> n;
}