int values[] = { 2, 6, 10, 14 };
What does each of the following display ?
A) cout << values[2]; // 10 
B) cout << ++values[0];  // 3
C) cout << values[1]++; // 6
D) x = 2; 
cout << values[++x]; // 14