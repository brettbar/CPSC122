
char greeting[] = { 'H', 'e', 'l', 'l', 'o' }; 
int size = 4;
for (int i = 0; i <= size; i++)
{
	cout << greeting[i];
}
// we need to use a for loop to access every part of the array and print them out together. just couting greeting only gives the memory
// location

